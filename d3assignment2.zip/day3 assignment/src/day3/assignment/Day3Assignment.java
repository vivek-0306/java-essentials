package day3.assignment;

import java.util.Scanner;
public class Day3Assignment {
    public static void main(String[] args) {
         Scanner sc=new Scanner(System.in);
        System.out.println("enter subject 1 marks");
        int s1=sc.nextInt();
        System.out.println("enter subject 2 marks");
        int s2=sc.nextInt();
        System.out.println("enter subject 3 marks");
        int s3=sc.nextInt();
        System.out.println("enter subject 4 marks");
        int s4=sc.nextInt();
        System.out.println("enter subject 5 marks");
        int s5=sc.nextInt();
        int sum=s1+s2+s3+s4+s5;
        float percentage=(sum*100)/500f;
        System.out.println(sum);
        if(percentage>85 && percentage<=100){
            System.out.println("GRADE A - "+percentage+"%");
        }
        else if(percentage>70 && percentage<=85){
            System.out.println("GRADE B - "+percentage+"%");
        }
        else if(percentage>55 && percentage<=70){
            System.out.println("GRADE C - "+percentage+"%");
        }
        else if(percentage>40 && percentage<=55){
            System.out.println("GRADE D - "+percentage+"%");
        }
        else if(percentage<=40){
            System.out.println("FAIL"+percentage+"%");
        }
        else{
            System.out.println("enter correct input");
        }
}
    }

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package d3assignment2;
import java.util.Date;
import java.util.Scanner;

/**
 *
 * @author Sai vivek
 */
public class D3assignment2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
         System.out.println("enter name of employee");
        String name=sc.next();
        System.out.println("enter birth day of employee");
        int day=sc.nextInt();
        System.out.println("enter birth month of employee");
        int month=sc.nextInt();
        System.out.println("enter birth year of employee");
        int year=sc.nextInt();
         Date d=new Date();
        int current_year=1900+d.getYear();
        int age=current_year-year;
        System.out.println("enter montly salary of employee");
        int m_salary=sc.nextInt();
        int salary=12*m_salary;
        System.out.println("employee name - "+name);
        System.out.println("employee age - "+age);
        System.out.println("employee annual salary - "+salary);
        float tax;
        if(salary>500000){
            tax=(salary*20)/100f;
            System.out.println("tax amount - "+tax);
        }
        else if(salary>400000){
            tax=(salary*15)/100f;
            System.out.println("tax amount - "+tax);
        }
        else if(salary>300000){
            tax=(salary*10)/100f;
            System.out.println("tax amount - "+tax);
        }
        else if(salary>200000){
            tax=(salary*5)/100f;
            System.out.println("tax amount - "+tax);
        }
            else{
                    System.out.println("no tax");
                    }
        }
    }
